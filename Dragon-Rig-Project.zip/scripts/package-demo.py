from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path('/workspace')
html = (root / 'dragon-follower-widget-demo.html').read_text()
instructions = '''ДРАКОН ДЛЯ OBS

1. Распакуйте архив целиком в постоянную папку.
2. Для проверки откройте TEST.html в Chrome/Edge/Firefox.
   Введите ник и нажмите «Новый фолловер».
3. В OBS: Источники → + → Браузер → Локальный файл.
   Выберите OBS.html. Размер: ширина 1200, высота 600. FPS: 60.
4. На прозрачном фоне дракон постоянно спит и дышит.

TEST.html — интерактивная демонстрация, работает без интернета.
OBS.html — прозрачный виджет без панели управления.

ВАЖНО: локальный файл самостоятельно не получает события Twitch.
Автоматические уведомления требуют подключения StreamElements.
GIF — только запись демонстрации, без кнопок и переменного никнейма.
Рык пока визуальный, без звука. Переходы используют три позы.
'''
with ZipFile(root / 'Dragon-OBS.zip', 'w', ZIP_DEFLATED) as archive:
    archive.writestr('Dragon/TEST.html', html)
    archive.writestr('Dragon/OBS.html', html.replace('<body>', '<body class="overlay">'))
    archive.writestr('Dragon/ИНСТРУКЦИЯ.txt', instructions)
    demo = root / 'dragon-current.gif'
    if demo.exists():
        archive.write(demo, 'Dragon/DEMO.gif')
print(root / 'Dragon-OBS.zip')
