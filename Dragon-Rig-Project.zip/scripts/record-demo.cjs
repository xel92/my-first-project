const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const dir = fs.mkdtempSync('/tmp/dragon-record-');
  const browser = await chromium.launch({headless:true, executablePath:'/usr/bin/chromium'});
  const page = await browser.newPage({viewport:{width:960,height:700}});
  await page.setContent(fs.readFileSync('/workspace/dragon-follower-widget-demo.html','utf8'));
  await page.fill('#name','LunaDragon_2026');
  for(let i=0;i<70;i++) {
    if(i===5) await page.click('button[type=submit]');
    await page.waitForTimeout(200);
    await page.screenshot({path:`${dir}/${String(i).padStart(3,'0')}.png`});
  }
  console.log(JSON.stringify({frames:dir, final:await page.locator('#widget').getAttribute('class')}));
  await browser.close();
  const { execFileSync } = require('child_process');
  execFileSync('ffmpeg',['-y','-loglevel','error','-framerate','5','-i',`${dir}/%03d.png`,'-vf','scale=720:-1:flags=lanczos,split[a][b];[a]palettegen[p];[b][p]paletteuse','/workspace/dragon-current.gif']);
})().catch(e=>{console.error(e);process.exit(1)});
